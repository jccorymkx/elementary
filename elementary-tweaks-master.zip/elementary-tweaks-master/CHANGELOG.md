* 1.0.1
  -  fix polkit issue

* 1.0
  - Themes (egtk 3.0 and egtk 2.0)
     - supports scrollbar width
     - supports scrollbar radius
     - supports dark tab underline
  - Terminal:
     - supports caret type
     - supports natural selection
     - supports warning
  - Fonts:
     - align all the combobox
  - Appearance:
     - write the style in the custom edit
  - Plank:
     - supports PressureReveal
     - supports PinnedOnly
     - supports AutoPinning
  - increase sidebar width to 160
  - fix critical warnings with CerbereSettings
  - disable `Ctrl` + `Space` to switch keyboard layout

  - remove C warnings
  - remove vala --save-temp warning
  - add CHANGELOG and README

* 0.2
  - initial release
